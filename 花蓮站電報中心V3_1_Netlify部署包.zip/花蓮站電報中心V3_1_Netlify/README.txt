花蓮站電報中心 V3.1 iPad 測試版
僅供虛構資料測試。
部署：將 index.html 所在資料夾拖放至 Netlify Drop，或上傳本資料夾的 ZIP。
無伺服器儲存，重新整理後資料會消失。
PDF 文字擷取會從第三方 CDN 載入 PDF.js；勿使用未授權內部文件。
